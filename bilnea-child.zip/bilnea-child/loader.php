<?php ?>

<div class="loader">
	<img src="" />
</div>