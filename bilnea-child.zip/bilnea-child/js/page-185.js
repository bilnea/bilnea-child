//JQuery especifico para una página en concreto, seleccionar la página mediante el ID de wordpress cambiando el nombre de este archivo (page-xxx.js)
jQuery(document).ready(function($) {

});